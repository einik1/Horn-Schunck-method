Files Included:

1)mainHornSchunck - Contains main func:
			a) Gets the image files from the given path
			b) Activates the HS function on every folloeing couple on image files
			c) Presents the results to the screen. 

2)myHornSchunck - Contains myHornSchunck:
			a) Calculates the U, V for the optycal flow vector

			myCompareGraphs:
			a) draws the quivers

3) inputs - Contains a couple of images, to use as inputs for the program

4) outputs - Contains the outputs of the program for the given inputs and diffrent alpha values (0.0001, 1.0, 100)

5)Result Explanation - PDF



How To Run The Program:

1) Project must include the following packeges: argparse, imageio, matplotlib, numpy, pyoptflow, pyparsing, scipy.

2) Run the mainHornSchunck.py script with the following arguments: InputPath, ImageType, AlphaParameter, NumberOfIterations
for example: C:\Users\kobi\Desktop\pyTemp\office *.bmp 1. 100



                                           
